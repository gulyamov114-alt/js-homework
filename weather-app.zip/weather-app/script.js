const API_KEY = "YOUR_API_KEY_HERE";
const BASE_URL = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline";

const searchForm = document.querySelector("#search-form");
const locationInput = document.querySelector("#location-input");
const searchButton = document.querySelector("#search-button");
const statusMessage = document.querySelector("#status");
const weatherContent = document.querySelector("#weather-content");
const fahrenheitButton = document.querySelector("#fahrenheit");
const celsiusButton = document.querySelector("#celsius");

let currentUnit = "C";
let weatherData = null;

function getWeatherIcon(icon) {
  const icons = {
    "clear-day": "☀️", "clear-night": "🌙",
    "partly-cloudy-day": "🌤️", "partly-cloudy-night": "☁️",
    "cloudy": "☁️", "rain": "🌧️", "showers-day": "🌦️",
    "showers-night": "🌧️", "thunder-rain": "⛈️",
    "thunder-showers-day": "⛈️", "thunder-showers-night": "⛈️",
    "snow": "❄️", "snow-showers-day": "🌨️", "snow-showers-night": "🌨️",
    "fog": "🌫️", "wind": "💨"
  };
  return icons[icon] || "🌡️";
}

function toCelsius(fahrenheit) {
  return (fahrenheit - 32) * 5 / 9;
}

function formatTemperature(fahrenheit) {
  const temperature = currentUnit === "C" ? toCelsius(fahrenheit) : fahrenheit;
  return Math.round(temperature);
}

function displayTemperature(fahrenheit) {
  return `${formatTemperature(fahrenheit)}°${currentUnit}`;
}

function formatDate(dateString, options = {}) {
  const date = new Date(`${dateString}T12:00:00Z`);
  return new Intl.DateTimeFormat("en", { timeZone: "UTC", ...options }).format(date);
}

async function getWeather(location) {
  if (!API_KEY || API_KEY === "YOUR_API_KEY_HERE") {
    throw new Error("Add your Visual Crossing API key in script.js first.");
  }

  const url = new URL(`${BASE_URL}/${encodeURIComponent(location)}/next7days`);
  url.search = new URLSearchParams({
    unitGroup: "us",
    key: API_KEY,
    contentType: "json"
  }).toString();

  const response = await fetch(url);

  if (!response.ok) {
    if (response.status === 400 || response.status === 404) {
      throw new Error("Location not found. Check the spelling and try again.");
    }
    if (response.status === 401 || response.status === 403) {
      throw new Error("API key rejected. Check your Visual Crossing key.");
    }
    if (response.status === 429) {
      throw new Error("API request limit reached. Please try again later.");
    }
    throw new Error(`Weather request failed (${response.status}).`);
  }

  const data = await response.json();
  console.log("Full API response:", data);
  return data;
}

function processWeather(data) {
  const current = data.currentConditions;

  return {
    location: data.resolvedAddress || data.address,
    timezone: data.timezone,
    current: {
      temperature: current.temp,
      feelsLike: current.feelslike,
      conditions: current.conditions,
      description: current.description || current.conditions,
      icon: current.icon,
      humidity: current.humidity,
      windSpeed: current.windspeed,
      uvIndex: current.uvindex,
      rainChance: current.precipprob,
      isDay: current.icon !== "clear-night" &&
        current.icon !== "partly-cloudy-night" &&
        current.icon !== "showers-night"
    },
    days: data.days.slice(0, 7).map(day => ({
      date: day.datetime,
      max: day.tempmax,
      min: day.tempmin,
      conditions: day.conditions,
      icon: day.icon,
      rainChance: day.precipprob
    }))
  };
}

function updateBackground(weather) {
  document.body.classList.remove("sunny", "cloudy", "rainy", "snowy", "night");

  const icon = weather.current.icon || "";
  const conditions = weather.current.conditions.toLowerCase();

  if (!weather.current.isDay) {
    document.body.classList.add("night");
  } else if (icon.includes("snow") || conditions.includes("snow")) {
    document.body.classList.add("snowy");
  } else if (
    icon.includes("rain") || icon.includes("showers") || icon.includes("thunder") ||
    conditions.includes("rain") || conditions.includes("drizzle") || conditions.includes("thunder")
  ) {
    document.body.classList.add("rainy");
  } else if (
    icon.includes("cloud") || icon.includes("fog") || icon.includes("wind") ||
    conditions.includes("overcast")
  ) {
    document.body.classList.add("cloudy");
  } else {
    document.body.classList.add("sunny");
  }
}

function displayCurrentWeather(weather) {
  const current = weather.current;

  document.querySelector("#city-name").textContent = weather.location;
  document.querySelector("#current-date").textContent = formatDate(weather.days[0].date, {
    weekday: "long", month: "long", day: "numeric"
  });
  document.querySelector("#conditions").textContent = current.conditions;
  document.querySelector("#current-temp").textContent = formatTemperature(current.temperature);
  document.querySelector("#feels-like").textContent = `Feels like ${displayTemperature(current.feelsLike)}`;
  document.querySelector("#high-low").textContent =
    `H: ${displayTemperature(weather.days[0].max)} · L: ${displayTemperature(weather.days[0].min)}`;
  document.querySelector("#weather-icon").textContent = getWeatherIcon(current.icon);
  document.querySelector("#weather-description").textContent = current.description;
  document.querySelector("#humidity").textContent = `${Math.round(current.humidity)}%`;
  document.querySelector("#wind").textContent = `${current.windSpeed} mph`;
  document.querySelector("#uv").textContent = current.uvIndex;
  document.querySelector("#rain").textContent = `${Math.round(current.rainChance)}%`;

  updateBackground(weather);
}

function displayForecast(days) {
  const forecastContainer = document.querySelector("#forecast");
  forecastContainer.replaceChildren();

  days.forEach((day, index) => {
    const card = document.createElement("article");
    card.className = "forecast-card";

    const dayLabel = document.createElement("p");
    dayLabel.className = "forecast-day";
    dayLabel.textContent = index === 0 ? "Today" : formatDate(day.date, { weekday: "short" });

    const icon = document.createElement("span");
    icon.className = "forecast-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = getWeatherIcon(day.icon);

    const conditions = document.createElement("p");
    conditions.className = "forecast-rain";
    conditions.textContent = day.conditions;

    const high = document.createElement("p");
    high.className = "forecast-high";
    high.textContent = displayTemperature(day.max);

    const low = document.createElement("p");
    low.className = "forecast-low";
    low.textContent = displayTemperature(day.min);

    const rain = document.createElement("p");
    rain.className = "forecast-rain";
    rain.textContent = `💧 ${Math.round(day.rainChance)}%`;

    card.append(dayLabel, icon, conditions, high, low, rain);
    forecastContainer.append(card);
  });
}

function renderWeather() {
  if (!weatherData) return;

  displayCurrentWeather(weatherData);
  displayForecast(weatherData.days);

  fahrenheitButton.classList.toggle("active", currentUnit === "F");
  celsiusButton.classList.toggle("active", currentUnit === "C");
  fahrenheitButton.setAttribute("aria-pressed", String(currentUnit === "F"));
  celsiusButton.setAttribute("aria-pressed", String(currentUnit === "C"));
}

searchForm.addEventListener("submit", async event => {
  event.preventDefault();
  const location = locationInput.value.trim();
  if (!location) return;

  searchButton.disabled = true;
  searchButton.textContent = "Loading...";
  statusMessage.textContent = "Fetching the latest forecast...";
  statusMessage.classList.remove("error");

  try {
    const apiData = await getWeather(location);
    weatherData = processWeather(apiData);
    renderWeather();
    weatherContent.hidden = false;
    statusMessage.textContent = `Forecast loaded for ${weatherData.location}.`;
  } catch (error) {
    console.error("Unable to fetch weather:", error);
    statusMessage.textContent = error.message || "Something went wrong. Please try again.";
    statusMessage.classList.add("error");
  } finally {
    searchButton.disabled = false;
    searchButton.textContent = "Search";
  }
});

fahrenheitButton.addEventListener("click", () => {
  currentUnit = "F";
  renderWeather();
});

celsiusButton.addEventListener("click", () => {
  currentUnit = "C";
  renderWeather();
});

celsiusButton.classList.add("active");
fahrenheitButton.setAttribute("aria-pressed", "false");
celsiusButton.setAttribute("aria-pressed", "true");
