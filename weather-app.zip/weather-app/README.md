# SkyCast Weather App

A responsive weather forecast app built with HTML, CSS, and vanilla JavaScript using the Visual Crossing Weather API.

## Setup
1. Get an API key from https://www.visualcrossing.com/weather-api
2. Open `script.js` and replace `YOUR_API_KEY_HERE` with your API key.
3. Open `index.html` in a browser, preferably through VS Code Live Server.
4. Search for a city and use the °C / °F buttons to switch units.

## Features
- Search by location
- Current conditions and seven-day forecast
- Fahrenheit / Celsius toggle
- Weather-based background themes
- Loading state and basic API error handling

## Note about API keys
This learning project places the API key in frontend JavaScript, where it is visible to visitors. For a production project, keep credentials on a backend server.
