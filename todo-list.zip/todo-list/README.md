# Todo List (The Odin Project)

    npm install
    npm run dev      # development server
    npm run build    # production build into dist/
    npm run deploy   # push dist/ to the gh-pages branch (after committing dist/)

Structure: `src/modules/todo.js` and `project.js` are factory functions, `app.js` holds the logic,
`storage.js` saves to localStorage (JSON), `dom.js` is the only module that touches the page.
