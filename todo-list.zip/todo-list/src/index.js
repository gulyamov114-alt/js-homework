import './style.css';
import * as app from './modules/app.js';
import { setup } from './modules/dom.js';

app.init();
setup();
