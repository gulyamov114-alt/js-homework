export const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

const EDITABLE = ['title', 'description', 'dueDate', 'priority'];

// Factory function: plain data + methods. JSON drops the methods, so
// loading from localStorage simply calls createTodo again with the saved data.
export function createTodo({ id = newId(), title = 'Untitled', description = '', dueDate = '', priority = 'low', completed = false } = {}) {
  return {
    id, title, description, dueDate, priority, completed,
    toggleComplete() { this.completed = !this.completed; },
    update(fields) {
      EDITABLE.forEach((key) => { if (key in fields) this[key] = fields[key]; });
    },
  };
}
