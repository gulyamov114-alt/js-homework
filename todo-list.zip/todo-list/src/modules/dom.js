// DOM code only: reads state from app.js and calls its functions.
import { format, isPast, isToday, isValid, parseISO } from 'date-fns';
import * as app from './app.js';

const $ = (sel) => document.querySelector(sel);
const el = (tag, props = {}, ...kids) => { const n = Object.assign(document.createElement(tag), props); n.append(...kids); return n; };
let expandedId = null;

function dueInfo(todo) {
  const date = todo.dueDate ? parseISO(todo.dueDate) : null;
  if (!date || !isValid(date)) return { text: 'No due date', overdue: false };
  if (isToday(date)) return { text: 'Today', overdue: false };
  return { text: format(date, 'MMM d, yyyy'), overdue: isPast(date) && !todo.completed };
}

function renderProjects() {
  $('#projects').replaceChildren(...app.getProjects().map((p) => el('li', {}, el('button', {
    type: 'button',
    className: 'project' + (p.id === app.getActiveId() ? ' active' : ''),
    onclick: () => { app.setActive(p.id); expandedId = null; render(); },
  }, el('span', { textContent: p.name }), el('span', { className: 'count', textContent: String(p.todos.length) })))));
}

function detailsForm(project, todo) {
  const form = el('form', { className: 'details' });
  form.innerHTML = `
    <label>Title <input name="title" required></label>
    <label>Description <textarea name="description" rows="3"></textarea></label>
    <label>Due date <input type="date" name="dueDate"></label>
    <label>Priority <select name="priority"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
    <div class="actions"><button type="submit" class="primary">Save</button><button type="button" class="danger">Delete</button></div>`;
  const f = form.elements;
  f.title.value = todo.title; f.description.value = todo.description; f.dueDate.value = todo.dueDate; f.priority.value = todo.priority;
  form.onsubmit = (e) => { e.preventDefault(); app.updateTodo(project.id, todo.id, Object.fromEntries(new FormData(form))); render(); };
  form.querySelector('.danger').onclick = () => { app.deleteTodo(project.id, todo.id); expandedId = null; render(); };
  return form;
}

function todoItem(project, todo) {
  const due = dueInfo(todo);
  const li = el('li', { className: 'todo' + (todo.completed ? ' done' : '') });
  li.dataset.priority = todo.priority;
  li.append(el('div', { className: 'row' },
    el('input', { type: 'checkbox', checked: todo.completed, onchange: () => { app.toggleTodo(project.id, todo.id); render(); } }),
    el('button', { type: 'button', className: 'title', textContent: todo.title, onclick: () => { expandedId = expandedId === todo.id ? null : todo.id; renderTodos(); } }),
    el('span', { className: 'due' + (due.overdue ? ' overdue' : ''), textContent: due.text })));
  if (expandedId === todo.id) li.append(detailsForm(project, todo));
  return li;
}

function renderTodos() {
  const project = app.getActive();
  $('#project-title').textContent = project.name;
  $('#todos').replaceChildren(...(project.todos.length
    ? project.todos.map((t) => todoItem(project, t))
    : [el('li', { className: 'empty', textContent: 'No todos yet. Add one!' })]));
}

function render() { renderProjects(); renderTodos(); }

export function setup() {
  const dialog = $('#todo-dialog');
  $('#new-todo').onclick = () => {
    $('#project-select').replaceChildren(...app.getProjects().map((p) => el('option', { value: p.id, textContent: p.name, selected: p.id === app.getActiveId() })));
    dialog.showModal();
  };
  $('#cancel').onclick = () => dialog.close();
  $('#todo-form').onsubmit = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    app.addTodo(data.project, data); app.setActive(data.project);
    e.target.reset(); dialog.close(); render();
  };
  $('#project-form').onsubmit = (e) => {
    e.preventDefault();
    app.addProject(new FormData(e.target).get('name'));
    e.target.reset(); expandedId = null; render();
  };
  render();
}
