import { createProject } from './project.js';
import { createTodo } from './todo.js';

const KEY = 'odin-todo-list';

export function saveProjects(projects) {
  try {
    localStorage.setItem(KEY, JSON.stringify(projects));
  } catch {
    /* storage full or unavailable: the app keeps working in memory */
  }
}

// Never throws: missing or corrupted data just means "start fresh".
export function loadProjects() {
  try {
    const data = JSON.parse(localStorage.getItem(KEY));
    if (!Array.isArray(data)) return [];
    return data.map((p) => createProject({ id: p.id, name: p.name, todos: (p.todos || []).map((t) => createTodo(t)) }));
  } catch {
    return [];
  }
}
