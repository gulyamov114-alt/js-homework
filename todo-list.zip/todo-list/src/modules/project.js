import { newId } from './todo.js';

export function createProject({ id = newId(), name = 'Untitled', todos = [] } = {}) {
  return {
    id, name, todos,
    addTodo(todo) { this.todos.push(todo); },
    removeTodo(todoId) { this.todos = this.todos.filter((t) => t.id !== todoId); },
    getTodo(todoId) { return this.todos.find((t) => t.id === todoId); },
  };
}
