// Application logic only: no DOM code lives here.
import { createProject } from './project.js';
import { createTodo } from './todo.js';
import { loadProjects, saveProjects } from './storage.js';

let projects = [];
let activeId = null;

const persist = () => saveProjects(projects);
const find = (id) => projects.find((p) => p.id === id);

export function init() {
  projects = loadProjects();
  if (projects.length === 0) {
    const home = createProject({ name: 'Default' });
    home.addTodo(createTodo({ title: 'Welcome! Click me to expand', description: 'Edit or delete this todo, or add your own.', priority: 'medium' }));
    projects = [home];
    persist();
  }
  activeId = projects[0].id;
}

export const getProjects = () => projects;
export const getActiveId = () => activeId;
export const getActive = () => find(activeId);
export const setActive = (id) => { if (find(id)) activeId = id; };

export function addProject(name) {
  const project = createProject({ name: name.trim() });
  projects.push(project);
  activeId = project.id;
  persist();
}

export function addTodo(projectId, data) {
  find(projectId).addTodo(createTodo(data));
  persist();
}

export function updateTodo(projectId, todoId, fields) {
  find(projectId).getTodo(todoId).update(fields);
  persist();
}

export function toggleTodo(projectId, todoId) {
  find(projectId).getTodo(todoId).toggleComplete();
  persist();
}

export function deleteTodo(projectId, todoId) {
  find(projectId).removeTodo(todoId);
  persist();
}
