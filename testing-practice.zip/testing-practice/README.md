# Testing practice (The Odin Project)

    npm install
    npm test

Each function in `src/` has a test file next to it: `capitalize`, `reverseString`, `calculator`,
`caesarCipher` (only the public function is tested, not its helper) and `analyzeArray`.
Babel is configured in `babel.config.cjs` so Jest can read `import` / `export`.
