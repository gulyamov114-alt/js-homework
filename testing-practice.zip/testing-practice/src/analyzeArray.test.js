import analyzeArray from './analyzeArray.js';

describe('analyzeArray', () => {
  test('returns average, min, max and length', () => {
    expect(analyzeArray([1, 8, 3, 4, 2, 6])).toEqual({ average: 4, min: 1, max: 8, length: 6 });
  });
  test('works with a single number', () => {
    expect(analyzeArray([7])).toEqual({ average: 7, min: 7, max: 7, length: 1 });
  });
  test('works with negative numbers and decimals', () => {
    expect(analyzeArray([-2, 0, 2.5])).toEqual({ average: 0.16666666666666666, min: -2, max: 2.5, length: 3 });
  });
  test('does not change the original array', () => {
    const input = [3, 1, 2];
    analyzeArray(input);
    expect(input).toEqual([3, 1, 2]);
  });
  test('throws for an empty array or a non-array', () => {
    expect(() => analyzeArray([])).toThrow();
    expect(() => analyzeArray('123')).toThrow(TypeError);
  });
  test('throws when the array contains non-numbers', () => {
    expect(() => analyzeArray([1, '2', 3])).toThrow(TypeError);
  });
});
