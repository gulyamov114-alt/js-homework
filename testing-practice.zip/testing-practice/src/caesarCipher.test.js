import caesarCipher from './caesarCipher.js';

describe('caesarCipher', () => {
  test('shifts letters forward', () => {
    expect(caesarCipher('abc', 1)).toBe('bcd');
  });
  test('wraps from z to a', () => {
    expect(caesarCipher('xyz', 3)).toBe('abc');
  });
  test('preserves letter case', () => {
    expect(caesarCipher('HeLLo', 3)).toBe('KhOOr');
  });
  test('leaves punctuation, spaces and digits unchanged', () => {
    expect(caesarCipher('Hello, World!', 3)).toBe('Khoor, Zruog!');
    expect(caesarCipher('a1 b2.', 1)).toBe('b1 c2.');
  });
  test('a shift of 0 or 26 returns the same text', () => {
    expect(caesarCipher('Hello', 0)).toBe('Hello');
    expect(caesarCipher('Hello', 26)).toBe('Hello');
  });
  test('supports shifts larger than 26', () => {
    expect(caesarCipher('abc', 29)).toBe('def');
  });
  test('supports negative shifts (decrypting)', () => {
    expect(caesarCipher('abc', -1)).toBe('zab');
    expect(caesarCipher(caesarCipher('Hello, World!', 7), -7)).toBe('Hello, World!');
  });
  test('returns an empty string for an empty string', () => {
    expect(caesarCipher('', 5)).toBe('');
  });
  test('throws for invalid input', () => {
    expect(() => caesarCipher(5, 1)).toThrow(TypeError);
    expect(() => caesarCipher('abc', 1.5)).toThrow(TypeError);
  });
});
