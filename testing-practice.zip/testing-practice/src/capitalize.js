export default function capitalize(string) {
  if (typeof string !== 'string') throw new TypeError('capitalize expects a string');
  return string.charAt(0).toUpperCase() + string.slice(1);
}
