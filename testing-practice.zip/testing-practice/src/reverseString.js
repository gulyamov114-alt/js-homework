export default function reverseString(string) {
  if (typeof string !== 'string') throw new TypeError('reverseString expects a string');
  return [...string].reverse().join('');
}
