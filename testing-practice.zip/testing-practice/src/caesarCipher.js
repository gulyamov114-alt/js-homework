const ALPHABET = 26;

function shiftLetter(char, shift) {
  const base = char === char.toUpperCase() ? 65 : 97; // 'A' or 'a'
  const position = char.charCodeAt(0) - base;
  return String.fromCharCode(base + ((((position + shift) % ALPHABET) + ALPHABET) % ALPHABET));
}

export default function caesarCipher(string, shift) {
  if (typeof string !== 'string') throw new TypeError('caesarCipher expects a string');
  if (!Number.isInteger(shift)) throw new TypeError('shift must be an integer');
  return string.replace(/[a-z]/gi, (char) => shiftLetter(char, shift));
}
