import reverseString from './reverseString.js';

describe('reverseString', () => {
  test('reverses a word', () => {
    expect(reverseString('hello')).toBe('olleh');
  });
  test('reverses a sentence including spaces and punctuation', () => {
    expect(reverseString('Hi, you!')).toBe('!uoy ,iH');
  });
  test('returns an empty string for an empty string', () => {
    expect(reverseString('')).toBe('');
  });
  test('a palindrome stays the same', () => {
    expect(reverseString('level')).toBe('level');
  });
  test('throws when the input is not a string', () => {
    expect(() => reverseString(null)).toThrow(TypeError);
  });
});
