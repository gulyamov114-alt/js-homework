import calculator from './calculator.js';

describe('calculator', () => {
  test('add', () => {
    expect(calculator.add(2, 3)).toBe(5);
    expect(calculator.add(-2, 3)).toBe(1);
  });
  test('add handles decimals', () => {
    expect(calculator.add(0.1, 0.2)).toBeCloseTo(0.3);
  });
  test('subtract', () => {
    expect(calculator.subtract(5, 3)).toBe(2);
    expect(calculator.subtract(3, 5)).toBe(-2);
  });
  test('multiply', () => {
    expect(calculator.multiply(4, 3)).toBe(12);
    expect(calculator.multiply(4, 0)).toBe(0);
    expect(calculator.multiply(-4, 3)).toBe(-12);
  });
  test('divide', () => {
    expect(calculator.divide(12, 4)).toBe(3);
    expect(calculator.divide(1, 4)).toBe(0.25);
  });
  test('divide by zero throws', () => {
    expect(() => calculator.divide(5, 0)).toThrow('Cannot divide by zero');
  });
  test('every operation rejects non-numbers', () => {
    ['add', 'subtract', 'multiply', 'divide'].forEach((op) => {
      expect(() => calculator[op]('2', 3)).toThrow(TypeError);
    });
  });
});
