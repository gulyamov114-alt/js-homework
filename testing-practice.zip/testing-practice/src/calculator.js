function check(a, b) {
  if (typeof a !== 'number' || typeof b !== 'number' || Number.isNaN(a) || Number.isNaN(b)) {
    throw new TypeError('Both arguments must be numbers');
  }
}

const calculator = {
  add(a, b) { check(a, b); return a + b; },
  subtract(a, b) { check(a, b); return a - b; },
  multiply(a, b) { check(a, b); return a * b; },
  divide(a, b) {
    check(a, b);
    if (b === 0) throw new RangeError('Cannot divide by zero');
    return a / b;
  },
};

export default calculator;
