export default function analyzeArray(numbers) {
  if (!Array.isArray(numbers)) throw new TypeError('analyzeArray expects an array');
  if (numbers.length === 0) throw new RangeError('The array must not be empty');
  if (numbers.some((n) => typeof n !== 'number' || Number.isNaN(n))) {
    throw new TypeError('The array must contain only numbers');
  }
  const sum = numbers.reduce((total, n) => total + n, 0);
  return {
    average: sum / numbers.length,
    min: Math.min(...numbers),
    max: Math.max(...numbers),
    length: numbers.length,
  };
}
