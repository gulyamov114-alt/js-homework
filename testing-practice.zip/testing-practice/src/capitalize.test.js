import capitalize from './capitalize.js';

describe('capitalize', () => {
  test('capitalizes the first character', () => {
    expect(capitalize('hello')).toBe('Hello');
  });
  test('leaves the rest of the string unchanged', () => {
    expect(capitalize('hELLO wORLD')).toBe('HELLO wORLD');
  });
  test('keeps an already capitalized string as it is', () => {
    expect(capitalize('Hello')).toBe('Hello');
  });
  test('does not change a string that starts with a non-letter', () => {
    expect(capitalize('123abc')).toBe('123abc');
    expect(capitalize(' hello')).toBe(' hello');
  });
  test('returns an empty string for an empty string', () => {
    expect(capitalize('')).toBe('');
  });
  test('throws when the input is not a string', () => {
    expect(() => capitalize(5)).toThrow(TypeError);
  });
});
