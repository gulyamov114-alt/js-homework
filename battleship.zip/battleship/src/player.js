import Gameboard, { SIZE } from './gameboard.js';
export default function Player(type = 'real') {
  if (!['real', 'computer'].includes(type)) throw new Error('Player type must be "real" or "computer"');
  const board = Gameboard();
  const queue = []; // squares next to a hit that the computer wants to try

  function pickRandom(enemy, rng) {
    const open = [];
    for (let x = 0; x < SIZE; x += 1) for (let y = 0; y < SIZE; y += 1) if (!enemy.wasAttacked([x, y])) open.push([x, y]);
    if (open.length === 0) throw new Error('No legal moves left');
    return open[Math.floor(rng() * open.length)];
  }

  function pickTarget(enemy, rng) {
    while (queue.length) {
      const next = queue.shift();
      if (!enemy.wasAttacked(next)) return next;
    }
    return pickRandom(enemy, rng);
  }

  function queueNeighbours(enemy, [x, y]) {
    [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]
      .filter(([nx, ny]) => nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && !enemy.wasAttacked([nx, ny]))
      .forEach((c) => queue.push(c));
  }

  function attack(enemy, coord, rng = Math.random) {
    if (type === 'real' && !coord) throw new TypeError('A real player needs a coordinate');
    const target = type === 'computer' ? pickTarget(enemy, rng) : coord;
    const result = enemy.receiveAttack(target);
    if (type === 'computer') {
      if (result === 'hit') queueNeighbours(enemy, target);
      if (result === 'sunk') queue.length = 0;
    }
    return { coord: target, result };
  }

  return { type, board, attack };
}
