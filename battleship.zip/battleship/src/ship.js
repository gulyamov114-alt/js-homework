export default function Ship(length) {
  if (!Number.isInteger(length) || length < 1) {
    throw new RangeError('Ship length must be a positive integer');
  }
  let hits = 0;
  return {
    length,
    get hits() { return hits; },
    hit() { if (hits < length) hits += 1; },
    isSunk() { return hits >= length; },
  };
}
