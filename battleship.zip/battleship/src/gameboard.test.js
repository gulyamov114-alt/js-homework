import Gameboard, { SIZE, FLEET } from './gameboard.js';

const seeded = (seed = 7) => () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
const countShipCells = (board) => {
  let n = 0;
  for (let x = 0; x < SIZE; x += 1) for (let y = 0; y < SIZE; y += 1) if (board.cellState([x, y]).hasShip) n += 1;
  return n;
};

describe('Gameboard placement', () => {
  test('places a ship horizontally and vertically', () => {
    const board = Gameboard();
    expect(board.placeShip(3, [0, 0], true)).toBe(true);
    expect(board.placeShip(2, [5, 5], false)).toBe(true);
    expect(board.cellState([2, 0]).hasShip).toBe(true);
    expect(board.cellState([5, 6]).hasShip).toBe(true);
    expect(board.cellState([3, 0]).hasShip).toBe(false);
  });
  test('rejects ships that go outside the board', () => {
    const board = Gameboard();
    expect(board.placeShip(3, [8, 0], true)).toBe(false);
    expect(board.placeShip(3, [0, 9], false)).toBe(false);
  });
  test('rejects overlapping ships', () => {
    const board = Gameboard();
    board.placeShip(3, [0, 0], true);
    expect(board.placeShip(2, [1, 0], false)).toBe(false);
  });
  test('placeRandomly places the whole fleet without overlap', () => {
    const board = Gameboard();
    board.placeRandomly(FLEET, seeded());
    expect(countShipCells(board)).toBe(FLEET.reduce((a, b) => a + b, 0));
  });
  test('reset empties the board', () => {
    const board = Gameboard();
    board.placeRandomly(FLEET, seeded());
    board.reset();
    expect(countShipCells(board)).toBe(0);
  });
});

describe('Gameboard attacks', () => {
  test('a shot on a ship is a hit', () => {
    const board = Gameboard();
    board.placeShip(3, [0, 0], true);
    expect(board.receiveAttack([1, 0])).toBe('hit');
  });
  test('a shot on empty water is a miss and is recorded', () => {
    const board = Gameboard();
    board.placeShip(3, [0, 0], true);
    expect(board.receiveAttack([5, 5])).toBe('miss');
    expect(board.getMissed()).toEqual([[5, 5]]);
  });
  test('reports sunk on the last hit of a ship', () => {
    const board = Gameboard();
    board.placeShip(2, [0, 0], true);
    expect(board.receiveAttack([0, 0])).toBe('hit');
    expect(board.receiveAttack([1, 0])).toBe('sunk');
  });
  test('rejects repeated and out-of-bounds attacks', () => {
    const board = Gameboard();
    board.receiveAttack([2, 2]);
    expect(() => board.receiveAttack([2, 2])).toThrow();
    expect(() => board.receiveAttack([10, 0])).toThrow(RangeError);
  });
  test('allSunk is false until every ship is sunk', () => {
    const board = Gameboard();
    expect(board.allSunk()).toBe(false);
    board.placeShip(1, [0, 0], true);
    board.placeShip(1, [3, 3], true);
    board.receiveAttack([0, 0]);
    expect(board.allSunk()).toBe(false);
    board.receiveAttack([3, 3]);
    expect(board.allSunk()).toBe(true);
  });
  test('cellState reports whether a coordinate was attacked', () => {
    const board = Gameboard();
    board.receiveAttack([4, 4]);
    expect(board.cellState([4, 4])).toEqual({ hasShip: false, attacked: true });
  });
});
