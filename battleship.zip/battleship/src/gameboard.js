import Ship from './ship.js';

export const SIZE = 10;
export const FLEET = [5, 4, 3, 3, 2];

const inBounds = (x, y) => Number.isInteger(x) && Number.isInteger(y) && x >= 0 && x < SIZE && y >= 0 && y < SIZE;
const key = (x, y) => `${x},${y}`;

export default function Gameboard() {
  const ships = [];
  const shipAt = new Map();
  const attacked = new Set();
  const missed = [];

  function placeShip(length, [x, y], horizontal = true) {
    const cells = Array.from({ length }, (_, i) => (horizontal ? [x + i, y] : [x, y + i]));
    if (cells.some(([cx, cy]) => !inBounds(cx, cy) || shipAt.has(key(cx, cy)))) return false;
    const ship = Ship(length);
    ships.push(ship);
    cells.forEach(([cx, cy]) => shipAt.set(key(cx, cy), ship));
    return true;
  }

  function placeRandomly(fleet = FLEET, rng = Math.random) {
    fleet.forEach((length) => {
      for (let attempt = 0; attempt < 1000; attempt += 1) {
        const coord = [Math.floor(rng() * SIZE), Math.floor(rng() * SIZE)];
        if (placeShip(length, coord, rng() < 0.5)) return;
      }
      throw new Error('Could not place all ships');
    });
  }

  function receiveAttack([x, y]) {
    if (!inBounds(x, y)) throw new RangeError('Attack is outside the board');
    if (attacked.has(key(x, y))) throw new Error('Coordinate already attacked');
    attacked.add(key(x, y));
    const ship = shipAt.get(key(x, y));
    if (!ship) {
      missed.push([x, y]);
      return 'miss';
    }
    ship.hit();
    return ship.isSunk() ? 'sunk' : 'hit';
  }

  return {
    placeShip,
    placeRandomly,
    receiveAttack,
    reset() { ships.length = 0; shipAt.clear(); attacked.clear(); missed.length = 0; },
    getMissed() { return missed.map((c) => [...c]); },
    wasAttacked([x, y]) { return attacked.has(key(x, y)); },
    cellState([x, y]) { return { hasShip: shipAt.has(key(x, y)), attacked: attacked.has(key(x, y)) }; },
    allSunk() { return ships.length > 0 && ships.every((s) => s.isSunk()); },
  };
}
