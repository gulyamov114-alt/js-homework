import Ship from './ship.js';

describe('Ship', () => {
  test('stores its length and starts with no hits', () => {
    const ship = Ship(3);
    expect(ship.length).toBe(3);
    expect(ship.hits).toBe(0);
    expect(ship.isSunk()).toBe(false);
  });
  test('hit() increases the number of hits', () => {
    const ship = Ship(3);
    ship.hit();
    ship.hit();
    expect(ship.hits).toBe(2);
    expect(ship.isSunk()).toBe(false);
  });
  test('is sunk once hits equal its length', () => {
    const ship = Ship(2);
    ship.hit();
    ship.hit();
    expect(ship.isSunk()).toBe(true);
  });
  test('hits never go above the length', () => {
    const ship = Ship(1);
    ship.hit();
    ship.hit();
    expect(ship.hits).toBe(1);
  });
  test('rejects an invalid length', () => {
    expect(() => Ship(0)).toThrow(RangeError);
    expect(() => Ship('3')).toThrow(RangeError);
  });
});
