// Turn order and win conditions live here, with no DOM code, so they can be tested.
import Player from './player.js';
import { FLEET } from './gameboard.js';

export default function Game(rng = Math.random) {
  let player;
  let computer;
  let started;
  let winner;

  function newGame() {
    player = Player('real');
    computer = Player('computer');
    player.board.placeRandomly(FLEET, rng);
    computer.board.placeRandomly(FLEET, rng);
    started = false;
    winner = null;
  }

  function reshuffle() {
    if (started) throw new Error('Ships cannot move after the game has started');
    player.board.reset();
    player.board.placeRandomly(FLEET, rng);
  }

  function playTurn(coord) {
    if (!started) throw new Error('Game has not started');
    if (winner) throw new Error('Game is over');
    const playerShot = player.attack(computer.board, coord);
    if (computer.board.allSunk()) {
      winner = 'player';
      return { playerShot, computerShot: null, winner };
    }
    const computerShot = computer.attack(player.board, undefined, rng);
    if (player.board.allSunk()) winner = 'computer';
    return { playerShot, computerShot, winner };
  }

  newGame();
  return {
    newGame,
    reshuffle,
    start() { started = true; },
    playTurn,
    get player() { return player; },
    get computer() { return computer; },
    get started() { return started; },
    get winner() { return winner; },
  };
}
