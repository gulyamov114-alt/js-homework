// The only module that touches the page. It reads from the game objects and draws.
import { SIZE } from './gameboard.js';

const $ = (sel) => document.querySelector(sel);
export const label = ([x, y]) => `${String.fromCharCode(65 + x)}${y + 1}`;
const WORDS = { miss: 'missed', hit: 'hit a ship', sunk: 'sank a ship' };

export function renderBoard(container, board, { reveal, onShoot }) {
  container.replaceChildren();
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      const { hasShip, attacked } = board.cellState([x, y]);
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'cell';
      cell.setAttribute('aria-label', label([x, y]));
      if (attacked) cell.classList.add(hasShip ? 'hit' : 'miss');
      else if (reveal && hasShip) cell.classList.add('ship');
      cell.disabled = !onShoot || attacked;
      if (onShoot) cell.addEventListener('click', () => onShoot([x, y]));
      container.append(cell);
    }
  }
}

export function setStatus(text) { $('#status').textContent = text; }
export const describeShot = (who, { coord, result }) => `${who} ${WORDS[result]} at ${label(coord)}.`;
export function setControls({ started }) {
  $('#shuffle').disabled = started;
  $('#start').disabled = started;
}
