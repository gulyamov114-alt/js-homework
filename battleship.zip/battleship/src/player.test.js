import Player from './player.js';
import Gameboard, { SIZE } from './gameboard.js';

describe('Player', () => {
  test('has its own gameboard and a type', () => {
    const a = Player('real');
    const b = Player('computer');
    expect(a.type).toBe('real');
    expect(b.type).toBe('computer');
    expect(a.board).not.toBe(b.board);
  });
  test('rejects unknown player types', () => {
    expect(() => Player('robot')).toThrow();
  });
  test('a real player attacks the coordinate it is given', () => {
    const enemy = Gameboard();
    enemy.placeShip(2, [0, 0], true);
    expect(Player('real').attack(enemy, [0, 0])).toEqual({ coord: [0, 0], result: 'hit' });
  });
  test('the computer never shoots the same coordinate twice', () => {
    const enemy = Gameboard();
    enemy.placeShip(3, [2, 2], true);
    const computer = Player('computer');
    const seen = new Set();
    for (let i = 0; i < SIZE * SIZE; i += 1) {
      seen.add(computer.attack(enemy).coord.join(','));
    }
    expect(seen.size).toBe(SIZE * SIZE);
    expect(() => computer.attack(enemy)).toThrow('No legal moves left');
  });
  test('after a hit the computer tries the neighbouring squares', () => {
    const enemy = Gameboard();
    enemy.placeShip(2, [5, 5], true);
    const computer = Player('computer');
    const first = computer.attack(enemy, undefined, () => 0.555); // picks [5, 5]
    expect(first).toEqual({ coord: [5, 5], result: 'hit' });
    expect(computer.attack(enemy)).toEqual({ coord: [6, 5], result: 'sunk' });
  });
});
