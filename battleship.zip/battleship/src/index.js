import './style.css';
import Game from './game.js';
import { renderBoard, setStatus, describeShot, setControls } from './dom.js';

let game = Game();
let message = 'Arrange your ships, then press Start game.';

function render() {
  const live = game.started && !game.winner;
  renderBoard(document.querySelector('#player-board'), game.player.board, { reveal: true });
  renderBoard(document.querySelector('#enemy-board'), game.computer.board, { reveal: false, onShoot: live ? shoot : null });
  setControls({ started: game.started });
  setStatus(message);
}

function shoot(coord) {
  const turn = game.playTurn(coord);
  message = describeShot('You', turn.playerShot);
  if (turn.computerShot) message += ` ${describeShot('Computer', turn.computerShot)}`;
  if (turn.winner) message = turn.winner === 'player' ? 'You win! All enemy ships are sunk.' : 'Computer wins! Your fleet is sunk.';
  render();
}

document.querySelector('#shuffle').addEventListener('click', () => { game.reshuffle(); render(); });
document.querySelector('#start').addEventListener('click', () => { game.start(); message = 'Your turn: click a square in Enemy waters.'; render(); });
document.querySelector('#new').addEventListener('click', () => { game = Game(); message = 'Arrange your ships, then press Start game.'; render(); });

render();
