import Game from './game.js';
import { SIZE } from './gameboard.js';

const shipCells = (board) => {
  let n = 0;
  for (let x = 0; x < SIZE; x += 1) for (let y = 0; y < SIZE; y += 1) if (board.cellState([x, y]).hasShip) n += 1;
  return n;
};

describe('Game', () => {
  test('a new game has both fleets placed and is not started', () => {
    const game = Game();
    expect(shipCells(game.player.board)).toBe(17);
    expect(shipCells(game.computer.board)).toBe(17);
    expect(game.started).toBe(false);
    expect(game.winner).toBe(null);
  });
  test('cannot play before the game starts', () => {
    expect(() => Game().playTurn([0, 0])).toThrow('Game has not started');
  });
  test('a turn is the player shot followed by the computer shot', () => {
    const game = Game();
    game.start();
    const turn = game.playTurn([0, 0]);
    expect(turn.playerShot.coord).toEqual([0, 0]);
    expect(turn.computerShot).not.toBe(null);
  });
  test('shooting the same square twice is rejected', () => {
    const game = Game();
    game.start();
    game.playTurn([3, 3]);
    expect(() => game.playTurn([3, 3])).toThrow();
  });
  test('the game ends when one fleet is sunk and no more turns are allowed', () => {
    const game = Game();
    game.start();
    for (let x = 0; x < SIZE && !game.winner; x += 1) {
      for (let y = 0; y < SIZE && !game.winner; y += 1) game.playTurn([x, y]);
    }
    expect(['player', 'computer']).toContain(game.winner);
    expect(() => game.playTurn([0, 0])).toThrow('Game is over');
  });
  test('ships can be reshuffled only before the game starts', () => {
    const game = Game();
    game.reshuffle();
    expect(shipCells(game.player.board)).toBe(17);
    game.start();
    expect(() => game.reshuffle()).toThrow();
  });
});
