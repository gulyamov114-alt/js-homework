# Battleship (The Odin Project)

    npm install
    npm test         # Jest unit tests (Ship, Gameboard, Player, Game)
    npm run dev      # development server
    npm run build    # production build into dist/
    npm run deploy   # push dist/ to gh-pages (commit dist/ first)

Modules: `ship.js`, `gameboard.js`, `player.js` and `game.js` have no DOM code and are fully tested.
`dom.js` renders boards; `index.js` wires the buttons and clicks to the game.
Extra credit included: the computer tries neighbouring squares after a hit.
